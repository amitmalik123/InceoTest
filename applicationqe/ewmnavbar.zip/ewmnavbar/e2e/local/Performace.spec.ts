import { test, expect } from '../../helper/fixtures';

test.describe.skip('PERFORMANCE', () => {

    ////// ---------- URL to LOGIN Loads--------------////
    test('Stopwatch > URL to Okta Login form', async ({ page, p, f, log }) => {
        const startTime = Date.now();

        await f.Browser.winGoToURL(process.env.URL!);
        await p.Login.fPassword.waitFor({ state: 'visible' });

        const endTime = Date.now();
        const duration = endTime - startTime;

        await log(`Page took ${duration} ms to show the Okta Login form.`);
        // expect(duration).toBeLessThan(2000);
    });

    test('Granular browser metrics (Navigation API) > URL to Okta Login form', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);

        await p.Login.fPassword.waitFor({ state: 'visible' });
        const performanceTiming = await page.evaluate(() => {
            const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;

            return {
                totalDuration: navigation.duration,
                dnsLookup: navigation.domainLookupEnd - navigation.domainLookupStart,
                domProcessing: navigation.domComplete - navigation.domInteractive,
                ttfb: navigation.responseStart - navigation.requestStart
            };
        });

        await log('Technical Metrics: ' + JSON.stringify(performanceTiming, null, 2));
        // expect(performanceTiming.dnsLookup).toBeLessThan(100);
    });

     test('Largest Contentful Paint (LCP) > URL to Okta Login form', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);
        await p.Login.fPassword.waitFor({ state: 'visible' });

        const lcp = await page.evaluate(() => {
            return new Promise((resolve) => {
                new PerformanceObserver((entryList) => {
                    const entries = entryList.getEntries();
                    const lastEntry = entries[entries.length - 1];
                    resolve(lastEntry.startTime);
                }).observe({ type: 'largest-contentful-paint', buffered: true });
            });
        });

        const lcpRounded = Math.round(Number(lcp));
        await log(`LCP (Largest Visual Element) loaded in: ${lcpRounded} ms`);

        // expect(lcpRounded).toBeLessThan(2000);
    });

    //// ---------- LOGIN to NAVBAR Loads--------------////

    test('Stopwatch > Credential Input to Login', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);

        await p.Login.fUserName.fill(process.env.USR_Global);
        await p.Login.fPassword.fill(process.env.PASS_Global);

        const startTime = Date.now();
        await p.Login.btnLogin.click();
        await p.Dashboard.smInsights.waitFor({ state: 'visible' });

        const endTime = Date.now();
        const duration = endTime - startTime;

        await log(`System Login Speed: ${duration} ms (Login to Dashboard).`);
    });

    test('Granular browser metrics (Navigation API) > Credential input to Login', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);

        await p.Login.Login(process.env.USR_Global, process.env.PASS_Global);
        await p.Dashboard.smInsights.waitFor({ state: 'visible' });

        const performanceTiming = await page.evaluate(() => {
            const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;

            if (!navigation) return null;

            return {
                totalDuration: navigation.duration,
                dnsLookup: navigation.domainLookupEnd - navigation.domainLookupStart,
                domProcessing: navigation.domComplete - navigation.domInteractive,
                ttfb: navigation.responseStart - navigation.requestStart
            };
        });

        if (performanceTiming) {
            await log('Technical Metrics (Dashboard): ' + JSON.stringify(performanceTiming, null, 2));

        } else {
            await log('Warning: No Navigation Timing found. (Are you testing an SPA?)');
        }
    });

    test('Largest Contentful Paint (LCP) > Credential input to Login', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);
        await p.Login.Login(process.env.USR_Global, process.env.PASS_Global);
        await p.Dashboard.smInsights.waitFor({ state: 'visible' });

        const lcp = await page.evaluate(() => {
            return new Promise((resolve) => {
                new PerformanceObserver((entryList) => {
                    const entries = entryList.getEntries();
                    const lastEntry = entries[entries.length - 1];
                    resolve(lastEntry.startTime);
                }).observe({ type: 'largest-contentful-paint', buffered: true });
            });
        });

        const lcpRounded = Math.round(Number(lcp));
        await log(`LCP (Login to Navbar) loaded in: ${lcpRounded} ms`);

        // expect(lcpRounded).toBeLessThan(2500); 
    });

    //// ---------- LOGIN to Dashboard Loads Fully--------------////

    test('Stopwatch > Login to Dashboard', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);

        await p.Login.fUserName.fill(process.env.USR_Global);
        await p.Login.fPassword.fill(process.env.PASS_Global);

        const startTime = Date.now();
        await p.Login.btnLogin.click();
        await p.Dashboard.secFees.waitFor({ state: 'visible' });

        const endTime = Date.now();
        const duration = endTime - startTime;

        await log(`System Login Speed: ${duration} ms (Login to Dashboard).`);
    });

    test('Granular browser metrics (Navigation API) > Login to Dashboard', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);

        await p.Login.Login(process.env.USR_Global, process.env.PASS_Global);
        await p.Dashboard.secFees.waitFor({ state: 'visible' });

        const performanceTiming = await page.evaluate(() => {
            const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;

            if (!navigation) return null;

            return {
                totalDuration: navigation.duration,
                dnsLookup: navigation.domainLookupEnd - navigation.domainLookupStart,
                domProcessing: navigation.domComplete - navigation.domInteractive,
                ttfb: navigation.responseStart - navigation.requestStart
            };
        });

        if (performanceTiming) {
            await log('Technical Metrics (Dashboard): ' + JSON.stringify(performanceTiming, null, 2));

        } else {
            await log('Warning: No Navigation Timing found. (Are you testing an SPA?)');
        }
    });

    test('Largest Contentful Paint (LCP) > Login to Dashboard', async ({ page, p, f, log }) => {
        await f.Browser.winGoToURL(process.env.URL!);
        await p.Login.Login(process.env.USR_Global, process.env.PASS_Global);
        await p.Dashboard.secFees.waitFor({ state: 'visible' });

        const lcp = await page.evaluate(() => {
            return new Promise((resolve) => {
                new PerformanceObserver((entryList) => {
                    const entries = entryList.getEntries();
                    const lastEntry = entries[entries.length - 1];
                    resolve(lastEntry.startTime);
                }).observe({ type: 'largest-contentful-paint', buffered: true });
            });
        });

        const lcpRounded = Math.round(Number(lcp));
        await log(`LCP (Login to Navbar) loaded in: ${lcpRounded} ms`);

        // expect(lcpRounded).toBeLessThan(2500); 
    });

    test.skip('(LCP with refresh) > Login to Dashboard', async ({ page, p, f, log }) => {
    await f.Browser.winGoToURL(process.env.URL!);
    
    const startLoginTime = performance.now();
    
    await p.Login.Login(process.env.USR_Global, process.env.PASS_Global);
    await p.Dashboard.secFees.waitFor({ state: 'visible' });

    const dashboardReadyTime = performance.now();

    const lcp = await page.evaluate(() => {
        return new Promise((resolve) => {
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                const lastEntry = entries[entries.length - 1];
                resolve(lastEntry ? lastEntry.startTime : 0);
            }).observe({ type: 'largest-contentful-paint', buffered: true });
        });
    });

    const lcpRounded = Math.round(Number(lcp));
    if (lcpRounded < (dashboardReadyTime - startLoginTime)) {
        await log(`⚠️ WARNING: accurate LCP not found. This is likely a Single Page App (SPA). Returned Old LCP: ${lcpRounded}ms`);
        await log(`Reverting to Stopwatch Measure: ${Math.round(dashboardReadyTime - startLoginTime)}ms`);
    } else {
        await log(`✅ Success: LCP (Dashboard Element) loaded in: ${lcpRounded} ms`);
    }
});
});
