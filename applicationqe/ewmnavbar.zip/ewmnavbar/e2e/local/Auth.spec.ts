import { test, expect } from '../../helper/fixtures';

test.describe('AUTH', () => {

    test('Collect Network calls before login', async ({ page, p, f, log }) => {

        await f.Browser.winGoToURL(process.env.URL!);
        await f.Browser.winGetCurrentURL();
        await f.Browser.winNetworkCallsRequest();
        await f.Browser.winNetworkCallsResponse();
        await f.Browser.winCookieGetAll();

    });

    test('Collect Network calls after login', async ({ page, p, f, log }) => {

        await f.Browser.winGoToURL(process.env.URL!);
        await p.Login.Login(process.env.USR_Global, process.env.PASS_Global);

        await f.Browser.winGetCurrentURL();

        await f.Browser.winNetworkCallsRequest();
        await f.Browser.winNetworkCallsResponse();
        await f.Browser.winCookieGetAll();

    });

});
