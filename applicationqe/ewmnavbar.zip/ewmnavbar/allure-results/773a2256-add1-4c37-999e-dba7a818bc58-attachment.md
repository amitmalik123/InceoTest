# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e5]:
    - heading "AssetMark-TSA logo logo" [level=1] [ref=e7]:
      - img "AssetMark-TSA logo logo" [ref=e8]
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]:
          - heading "Sign In" [level=2] [ref=e14]
          - generic [ref=e15]:
            - generic [ref=e16]:
              - generic [ref=e17]: Username
              - textbox "Username" [active] [ref=e20]:
                - /placeholder: ""
            - generic [ref=e21]:
              - generic [ref=e22]: Password
              - textbox "Password" [ref=e25]:
                - /placeholder: ""
            - generic [ref=e29]:
              - checkbox "Remember me" [ref=e30]
              - generic [ref=e31] [cursor=pointer]: Remember me
        - button "Sign In" [ref=e33]
      - link "Need help signing in?" [ref=e35] [cursor=pointer]:
        - /url: "#"
  - generic [ref=e37]:
    - paragraph [ref=e38]:
      - text: Powered by
      - link "Okta" [ref=e39] [cursor=pointer]:
        - /url: https://www.okta.com/?internal_link=wic_login
    - paragraph [ref=e40]:
      - link "Privacy Policy" [ref=e41] [cursor=pointer]:
        - /url: /privacy
```