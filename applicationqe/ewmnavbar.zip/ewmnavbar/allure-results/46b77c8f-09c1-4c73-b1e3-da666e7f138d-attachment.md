# Page snapshot

```yaml
- generic [ref=e3]:
  - progressbar [ref=e4]:
    - img [ref=e5]
  - heading "Loading..." [level=6] [ref=e7]
```